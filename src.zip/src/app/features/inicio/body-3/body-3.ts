import { Component } from '@angular/core';

@Component({
  selector: 'app-body-3',
  imports: [],
  templateUrl: './body-3.html',
  styleUrl: './body-3.scss'
})
export class Body3 {

}
