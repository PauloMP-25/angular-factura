import { Component } from '@angular/core';

@Component({
  selector: 'app-body-2',
  imports: [],
  templateUrl: './body-2.html',
  styleUrl: './body-2.scss'
})
export class Body2 {

}
