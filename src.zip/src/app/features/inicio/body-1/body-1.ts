import { Component } from '@angular/core';
import { CommonModule } from '@angular/common';

@Component({
  selector: 'app-body-1',
  standalone: true,
  imports: [CommonModule],
  templateUrl: './body-1.html',
  styleUrl: './body-1.scss'
})
export class Body1 {

}
