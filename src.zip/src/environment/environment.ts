// Este archivo es para desarrollo local (ng serve)
export const environment = {
    production: false,
    apiUrl: 'http://localhost:8080',
};